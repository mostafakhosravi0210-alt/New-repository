# NutriLife AI — پروژه اندروید (Capacitor)

## ساخت APK / AAB
1. نصب Node.js 20+ و Android Studio.
2. در همین پوشه: `npm install` سپس `npx cap add android` و `npx cap sync android`
3. `npx cap open android` ← در Android Studio دکمه Run (تست) یا Build ← Generate Signed Bundle/APK (انتشار).
4. بعد از هر تغییر در `www/`: `npx cap sync android`

## قبل از انتشار
- فونت: فایل Vazirmatn.woff2 را در `www/fonts/` بگذار (اپ بدون آن هم با فونت سیستم کار می‌کند).
- تنظیمات سرویس: مقادیر `APP_CONFIG` را در انتهای `www/index.html` پر کن (فقط anon key، هرگز service_role).
- بعد از تغییر فایل‌های وب، عدد `V` در `www/sw.js` را بالا ببر.

## Supabase (اختیاری، برای همگام‌سازی)
```sql
create table user_nutrition_data(user_id uuid primary key references auth.users(id) on delete cascade, data jsonb, updated_at timestamptz default now());
alter table user_nutrition_data enable row level security;
create policy own on user_nutrition_data for all using (auth.uid()=user_id) with check (auth.uid()=user_id);
```

## تشخیص عکس غذا (اختیاری)
سرور خودت باید multipart با فیلد `image` بگیرد و JSON با name, grams, kcal, protein, carbs, fat, confidence برگرداند. کلید مدل فقط روی سرور.
